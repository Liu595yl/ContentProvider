package com.example.contentprovide;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ContentProvider2 extends AppCompatActivity {
     private  MyDatabaseHelper dbHelper;
     private Button createDatabase;
     private Button addData;
     private Button updateData;
     private Button deleteData;
     private Button queryData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content_provider2);
        Log.d("表里的内容：","创建数据库了");
        dbHelper = new MyDatabaseHelper(this, "Test.db", null, 2);
        Log.d("表里的内容：","创建数据库了");
        createDatabase = (Button) findViewById(R.id.create_database);
        Log.d("表里的内容：","创建数据库了");
        createDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.getWritableDatabase();
                Log.d("表里的内容：","创建数据库了");
            }
        });
         addData = (Button) findViewById(R.id.add_data);
         addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db=dbHelper.getWritableDatabase();
                dbHelper.getWritableDatabase();
                ContentValues values=new ContentValues();

                values.put("name","张三"); values.put("phone",123456); values.put("sex","女");
                db.insert("Contacts",null,values);
                values.clear();
                values.put("name","李四"); values.put("phone",123666); values.put("sex","男");
                db.insert("Contacts",null,values);
                values.clear();
                values.put("name","33"); values.put("phone",123888); values.put("sex","男");
                db.insert("Contacts",null,values);
                Log.d("表里的内容：","添加了");
            }
        });
        updateData = (Button) findViewById(R.id.update_data);
        updateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db=dbHelper.getWritableDatabase();
                ContentValues values=new ContentValues();

                values.put("name","lisa");
                db.update("Contacts",values,"sex=?",new String[]{"女"});
                Log.d("表里的内容：","更新了");
            }
        });

        deleteData = (Button) findViewById(R.id.delete_data);
        deleteData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db=dbHelper.getWritableDatabase();
                db.delete("Contacts","name=?",new String[]{"33"});
                Log.d("表里的内容：","删除了");
            }
        });

        queryData = (Button) findViewById(R.id.query_data);
        queryData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db=dbHelper.getWritableDatabase();
                Cursor cursor=db.query("Contacts",null,null,null,null,null,null);
                if(cursor.moveToFirst()){
                    do{
                        @SuppressLint("Range") String name=cursor.getString(cursor.getColumnIndex("name"));
                        @SuppressLint("Range") int phone=cursor.getInt(cursor.getColumnIndex("phone"));
                        @SuppressLint("Range") String sex=cursor.getString(cursor.getColumnIndex("sex"));
                        Log.d("表里的内容：","name:"+name+"  phone:"+phone+"  sex:"+sex);
                    }while(cursor.moveToNext());
                }
                cursor.close();
            }
        });
    }




}